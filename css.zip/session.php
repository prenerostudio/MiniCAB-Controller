<?php
session_start();  // Ensure session_start() is at the very beginning

error_log('Session started');
// Turn off display errors, but it's better to handle errors correctly
ini_set("display_errors", "off");

// Check if the user is logged in by verifying if 'email' is set in the session
if (!isset($_SESSION['email'])) {	
	$_SESSION['msg'] = "You must log in first";	
	header('location: index.php');
	exit;
}

// If the user is logged in, retrieve session variables
$myId = $_SESSION['user_id'];
$email = $_SESSION['email'];                		
$fname = $_SESSION['first_name'];                		
$lname = $_SESSION['last_name'];               		
$userphone = $_SESSION['user_phone'];                            			                		
$user_pic = $_SESSION['user_pic'];		
$designation = $_SESSION['designation'];
?>
