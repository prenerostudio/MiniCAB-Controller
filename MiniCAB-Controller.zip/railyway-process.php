<?php
require 'config.php';
include('session.php');


$r_name = $_POST['r_name'];

$r_address = $_POST['r_address'];


$sql = "INSERT INTO `railway_stations`(
				`rail_name`, 
				`rail_address`
				) VALUES (
				'$r_name',
				'$r_address')"; 


$result = mysqli_query($connect, $sql);       

if ($result) { 	

    $activity_type = 'Railyway Station Added';	

    $user_type = 'user';	

    $details = "Railyway Station Has Been Added by Controller.";
	

    $actsql = "INSERT INTO `activity_log`(
					`activity_type`, 
					`user_type`, 
					`user_id`, 
					`details`
					) VALUES (
					'$activity_type',
					'$user_type',
					'$myId',
					'$details')";	

    $actr = mysqli_query($connect, $actsql);

    header('Location: railway_stations.php');    

    exit();    
} else {		

    header('Location: railway_stations.php');    
}

$connect->close();
?>