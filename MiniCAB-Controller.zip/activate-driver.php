<?php
include('config.php');
include('session.php');
$d_id = $_GET['d_id'];
$status = 1;
$sql = "UPDATE `drivers` SET `acount_status`='$status' WHERE `d_id`='$d_id'";
$result = $connect->query($sql);
if($result){
    $activity_type = 'Activate Driver';        		
    $user_type = 'user';        		
    $details = "Driver ID: " . $d_id . " Has Been Activated";
    $actsql = "INSERT INTO `activity_log`(
					`activity_type`, 
					`user_type`, 
					`user_id`, 
					`details`
					) VALUES (
					'$activity_type',
					'$user_type',
					'$myId',
					'$details')";
    $actr = mysqli_query($connect, $actsql);
    header('location: drivers.php');	
} else {	
    header('location: drivers.php');	
}
?>